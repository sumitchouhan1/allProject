package dao;
import javax.transaction.Transactional;


import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.capstore.bean.CartProduct;

@Transactional
public interface capstoreDao3  extends JpaRepository<CartProduct, Integer> {

}
