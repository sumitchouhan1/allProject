package dao;
import javax.transaction.Transactional;


import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.capstore.bean.Invoice;

@Transactional
public interface capstoreDao8  extends JpaRepository<Invoice, Long> {

}
