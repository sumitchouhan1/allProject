package dao;
import javax.transaction.Transactional;


import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.capstore.bean.WishList;

@Transactional
public interface capstoreDao13  extends JpaRepository<WishList, Integer> {

}
