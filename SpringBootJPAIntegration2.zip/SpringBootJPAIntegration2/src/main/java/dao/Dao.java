/*import org.springframework.data.jpa.repository.support.JpaRepositoryFactory;
*/
/*package com.cg.capstore.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cg.capstore.bean.Admin;
import com.cg.capstore.bean.CartProduct;
import com.cg.capstore.bean.Coupon;
import com.cg.capstore.bean.Customer;
import com.cg.capstore.bean.Feedback;
import com.cg.capstore.bean.Image;
import com.cg.capstore.bean.Invoice;
import com.cg.capstore.bean.Merchant;
import com.cg.capstore.bean.Address;
import com.cg.capstore.bean.Cart;
import com.cg.capstore.bean.Orders;
import com.cg.capstore.bean.WishList;
import com.cg.capstore.bean.Product;
import com.cg.capstore.bean.SavedCardDetails;

@Repository
@Transactional
public class Dao
{
	@PersistenceContext
	EntityManager em;
	

	Address myaddress = new Address();
	
	Admin admin= new Admin();

	Coupon coupon= new Coupon();

	Customer customer= new Customer();

	Feedback feedback = new Feedback();
	 

	Image image=new Image();
	
	Invoice invoice= new Invoice();

	Merchant merchant= new Merchant();
	
	Cart cart= new Cart();

	Orders orders= new Orders();

	WishList wishlist= new WishList();

	Product product= new Product();
	
	CartProduct cartprod = new CartProduct();

	SavedCardDetails cardDetails = new SavedCardDetails();

	 public void manage()
	 {
			
		em.persist(admin);
		em.persist(coupon);
		em.persist(myaddress);
		em.persist(image);
		em.persist(invoice);
	
		em.persist(product);
		
		em.persist(wishlist);
		em.persist(cart);
		em.persist(orders);
		em.persist(customer);
		em.persist(cardDetails);
		em.persist(merchant);
		em.persist(cartprod);
		em.persist(feedback);
	 }
}
*/

