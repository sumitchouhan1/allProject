package dao;
import javax.transaction.Transactional;


import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.capstore.bean.Address;

@Transactional
public interface capstoreDao  extends JpaRepository<Address, String> {

}
