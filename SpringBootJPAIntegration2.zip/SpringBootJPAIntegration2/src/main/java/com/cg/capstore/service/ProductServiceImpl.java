package com.cg.capstore.service;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.capstore.bean.Product;
import com.cg.capstore.exception.DuplicateIdException;
import com.cg.capstore.exception.InvalidIdException;
import com.cg.capstore.exception.productDoesNotExistsException;
import com.cg.capstore.repo.IProductRepo;

@Service
public class ProductServiceImpl implements IProductService {
	
	@Autowired
	IProductRepo productRepo;
	@Override
	public Product addProduct(Product product) throws  DuplicateIdException{
		return productRepo.addProduct(product);
	}

	@Override
	public Product findProduct(String productId) throws InvalidIdException {
		return productRepo.findProduct(productId);
	}

	@Override
	public Product updateProduct(Product product) throws productDoesNotExistsException {
		return productRepo.updateProduct(product);
	}

	@Override
	public List<Product> getProductList() throws productDoesNotExistsException {
		return productRepo.getProductList();
	}

	@Override
	public Product removeProduct(String productId) throws InvalidIdException {
		return productRepo.removeProduct(productId);
	}

	

}
