package com.cg.capstore.bean;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name= "CartProduct")
public class CartProduct {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int CartProductId;
	@OneToOne
	private Product product;
	private int Quantity;
	@ManyToOne
	private Cart cart;
	
	/*Constructors*/
	
	public CartProduct(int cartProductId, Product product, int quantity, Cart cart) {
		super();
		CartProductId = cartProductId;
		this.product = product;
		Quantity = quantity;
		this.cart = cart;
	}



	public CartProduct(int cartProductId) {
		super();
		CartProductId = cartProductId;
	}



	public CartProduct() {
		super();
	}

	/*Getters and Setters*/


	public int getCartProductId() {
		return CartProductId;
	}



	public Product getProduct() {
		return product;
	}



	public int getQuantity() {
		return Quantity;
	}



	public Cart getCart() {
		return cart;
	}



	public void setCartProductId(int cartProductId) {
		CartProductId = cartProductId;
	}



	public void setProduct(Product product) {
		this.product = product;
	}



	public void setQuantity(int quantity) {
		Quantity = quantity;
	}



	public void setCart(Cart cart) {
		this.cart = cart;
	}



	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("CartProduct [CartProductId=");
		builder.append(CartProductId);
		builder.append(", product=");
		builder.append(product);
		builder.append(", Quantity=");
		builder.append(Quantity);
		builder.append(", cart=");
		builder.append(cart);
		builder.append("]");
		return builder.toString();
	}
	
	
	
	
	
	

}
