package com.cg.capstore.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Invoice")
public class Invoice
{
	@Id
	@Column(name="invoiceId")
	private String invoiceId;
	@Column(name="paymentOptions")
	private String paymentOptions;
	@Column(name="transactionId")
	private long transactionId;
	
	public Invoice() 
	{
		super();
	}

	public Invoice(String invoiceId, String paymentOptions, long transactionId) {
		super();
		this.invoiceId = invoiceId;
		this.paymentOptions = paymentOptions;
		this.transactionId = transactionId;
	}

	public Invoice(String invoiceId) {
		super();
		this.invoiceId = invoiceId;
	}

	public String getInvoiceId() {
		return invoiceId;
	}

	public String getPaymentOptions() {
		return paymentOptions;
	}

	public long getTransactionId() {
		return transactionId;
	}

	public void setInvoiceId(String invoiceId) {
		this.invoiceId = invoiceId;
	}

	public void setPaymentOptions(String paymentOptions) {
		this.paymentOptions = paymentOptions;
	}

	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Invoice [invoiceId=");
		builder.append(invoiceId);
		builder.append(", paymentOptions=");
		builder.append(paymentOptions);
		builder.append(", transactionId=");
		builder.append(transactionId);
		builder.append("]");
		return builder.toString();
	}

	
}
