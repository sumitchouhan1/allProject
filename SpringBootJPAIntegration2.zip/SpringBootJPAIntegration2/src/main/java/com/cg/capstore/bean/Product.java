package com.cg.capstore.bean;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="Product")
public class Product
{
	@Id
	@Column(name="prodId",length=10)
	private String prodId;
	@Column(name="name",length=70)
	private String name;
	@Column(name="sizes",length=5)
	private String sizes;
	@Column(name="initalQuantity",length=5)	
	private int initialQuantity;
	@Column(name="availableQuantity",length=5)	
	private int availableQuantity;
	@Column(name="price",length=6)
	private double price;
	@Column(name="rating",length=5)
	private double rating;
	@Column(name="prodCategory",length=50)
	private String prodCategory;
	@Column(name="discount",length=5)
	private double prodDiscount;
	
	@ManyToMany(mappedBy="prodCoupon")
//	@JoinTable(name="product_coupon",
//				joinColumns=@JoinColumn(name="prod_id")
//				,inverseJoinColumns=@JoinColumn(name="coupon_id"))
	private List<Coupon> prodCoupon;
	
	
	
	@ManyToMany
	@JoinTable(name="merchantProduct",joinColumns=@JoinColumn(name="merchantId"),
				inverseJoinColumns=@JoinColumn(name="prodId"))
	private List<Merchant> merchantProduct;
	
	
	@ManyToMany
	@JoinTable(name="prodImages",joinColumns=@JoinColumn(name="prodId"),
			inverseJoinColumns=@JoinColumn(name="imageId"))
	private List<Image> prodImages;

	
	@ManyToMany(mappedBy="prodFeedback")
//	@JoinTable(name="product_feedback"
//			,joinColumns=@JoinColumn(name="prod_id")
//			,inverseJoinColumns= @JoinColumn(name="feedback_id")
//			)
	private List<Feedback> prodFeedback;
	
	@ManyToMany(mappedBy="wishListProduct")
//	@JoinTable(name="wishlist_product",
//				joinColumns=@JoinColumn(name="prod_id"),
//				inverseJoinColumns=@JoinColumn(name="wishlist_id"))
	private List<WishList> wishList;
	
	@ManyToMany(mappedBy="ordersProduct")
//	@JoinTable(name="orders_product",
//				joinColumns=@JoinColumn(name="order_id"),
//				inverseJoinColumns=@JoinColumn(name="prod_id"))
	private List<Orders> ordersProduct;
	
	@ManyToMany
	@JoinTable(name="cartProduct",
				joinColumns=@JoinColumn(name="cartId"),
				inverseJoinColumns=@JoinColumn(name="prodId"))
	private List<Cart> cartProduct;
/*
	@ManyToMany(mappedBy="prod_images")
//	@JoinTable(name="prod_images",
//			joinColumns=@JoinColumn(name="image_id"),
//			inverseJoinColumns=@JoinColumn(name="prod_id")
//			)
	private List<Product> productImg;*/
	
	public Product() 
	{
		super();
	}

	public Product(String prodId, String name, String sizes, int initialQuantity, int availableQuantity, double price,
			double rating, String prodCategory, double prodDiscount, List<Coupon> prodCoupon,
			List<Merchant> merchantProduct, List<Image> prodImages, List<Feedback> prodFeedback,
			List<WishList> wishlist, List<Orders> ordersProduct, List<Cart> cartProduct) {
		super();
		this.prodId = prodId;
		this.name = name;
		this.sizes = sizes;
		this.initialQuantity = initialQuantity;
		this.availableQuantity = availableQuantity;
		this.price = price;
		this.rating = rating;
		this.prodCategory = prodCategory;
		this.prodDiscount = prodDiscount;
		this.prodCoupon = prodCoupon;
		this.merchantProduct = merchantProduct;
		this.prodImages = prodImages;
		this.prodFeedback = prodFeedback;
		this.wishList = wishlist;
		this.ordersProduct = ordersProduct;
		this.cartProduct = cartProduct;
	}

	public Product(String prodId) {
		super();
		this.prodId = prodId;
	}

	public String getProdId() {
		return prodId;
	}

	public String getName() {
		return name;
	}

	public String getSizes() {
		return sizes;
	}

	public int getInitialQuantity() {
		return initialQuantity;
	}

	public int getAvailableQuantity() {
		return availableQuantity;
	}

	public double getPrice() {
		return price;
	}

	public double getRating() {
		return rating;
	}

	public String getProdCategory() {
		return prodCategory;
	}

	public double getProdDiscount() {
		return prodDiscount;
	}

	public List<Coupon> getProdCoupon() {
		return prodCoupon;
	}

	public List<Merchant> getMerchantProduct() {
		return merchantProduct;
	}

	public List<Image> getProdImages() {
		return prodImages;
	}

	public List<Feedback> getProdFeedback() {
		return prodFeedback;
	}

	public List<WishList> getWishlist() {
		return wishList;
	}

	public List<Orders> getOrdersProduct() {
		return ordersProduct;
	}

	public List<Cart> getCartProduct() {
		return cartProduct;
	}

	public void setProdId(String prodId) {
		this.prodId = prodId;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setSizes(String sizes) {
		this.sizes = sizes;
	}

	public void setInitialQuantity(int initialQuantity) {
		this.initialQuantity = initialQuantity;
	}

	public void setAvailableQuantity(int availableQuantity) {
		this.availableQuantity = availableQuantity;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public void setRating(double rating) {
		this.rating = rating;
	}

	public void setProdCategory(String prodCategory) {
		this.prodCategory = prodCategory;
	}

	public void setProdDiscount(double prodDiscount) {
		this.prodDiscount = prodDiscount;
	}

	public void setProdCoupon(List<Coupon> prodCoupon) {
		this.prodCoupon = prodCoupon;
	}

	public void setMerchantProduct(List<Merchant> merchantProduct) {
		this.merchantProduct = merchantProduct;
	}

	public void setProdImages(List<Image> prodImages) {
		this.prodImages = prodImages;
	}

	public void setProdFeedback(List<Feedback> prodFeedback) {
		this.prodFeedback = prodFeedback;
	}

	public void setWishlist(List<WishList> wishlist) {
		this.wishList = wishlist;
	}

	public void setOrdersProduct(List<Orders> ordersProduct) {
		this.ordersProduct = ordersProduct;
	}

	public void setCartProduct(List<Cart> cartProduct) {
		this.cartProduct = cartProduct;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Product [prodId=");
		builder.append(prodId);
		builder.append(", name=");
		builder.append(name);
		builder.append(", sizes=");
		builder.append(sizes);
		builder.append(", initialQuantity=");
		builder.append(initialQuantity);
		builder.append(", availableQuantity=");
		builder.append(availableQuantity);
		builder.append(", price=");
		builder.append(price);
		builder.append(", rating=");
		builder.append(rating);
		builder.append(", prodCategory=");
		builder.append(prodCategory);
		builder.append(", prodDiscount=");
		builder.append(prodDiscount);
		builder.append(", prodCoupon=");
		builder.append(prodCoupon);
		builder.append(", merchantProduct=");
		builder.append(merchantProduct);
		builder.append(", prodImages=");
		builder.append(prodImages);
		builder.append(", prodFeedback=");
		builder.append(prodFeedback);
		builder.append(", wishlist=");
		builder.append(wishList);
		builder.append(", ordersProduct=");
		builder.append(ordersProduct);
		builder.append(", cartProduct=");
		builder.append(cartProduct);
		builder.append("]");
		return builder.toString();
	}
	
	
	
	
}
