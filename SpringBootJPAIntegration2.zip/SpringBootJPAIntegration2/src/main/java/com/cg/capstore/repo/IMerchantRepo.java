package com.cg.capstore.repo;

import java.util.List;



import org.springframework.stereotype.Repository;

import com.cg.capstore.bean.Merchant;
import com.cg.capstore.exception.DuplicateIdException;
import com.cg.capstore.exception.InvalidIdException;
import com.cg.capstore.exception.merchantDoesNotExistsException;

@Repository
public interface IMerchantRepo
{
	Merchant addMerchant(Merchant merchant) throws DuplicateIdException; 
	Merchant findMerchant(String id) throws InvalidIdException;
	Merchant updateMerchant(Merchant merchant) throws merchantDoesNotExistsException;
	List<Merchant> getMerchantList() throws merchantDoesNotExistsException;
	Merchant removeMerchant(String merchantId) throws InvalidIdException;
}
