package com.cg.capstore.service;

import java.util.List;



import org.springframework.stereotype.Service;

import com.cg.capstore.bean.Product;
import com.cg.capstore.exception.DuplicateIdException;
import com.cg.capstore.exception.InvalidIdException;
import com.cg.capstore.exception.productDoesNotExistsException;

@Service
public interface IProductService {
	Product addProduct(Product product) throws DuplicateIdException; 
	Product findProduct(String productId) throws InvalidIdException;
	Product updateProduct(Product product) throws productDoesNotExistsException;
	List<Product> getProductList() throws productDoesNotExistsException;
	Product removeProduct(String productId) throws InvalidIdException;

}
