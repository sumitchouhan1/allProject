package com.cg.capstore.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="capstoreAdmin")
public class Admin
{
	@Id
	@Column(name="mobileNo",length=10)
	private String mobileNo;
	@Column(name="name",length=50)
	private String name;
	@Column(name="password",length=20)
	private String password;
	@Column(name="email",length=70)
	private String email;
	
	
	public Admin()
	{
		super();
	}

	

	public Admin(String mobileNo, String name, String password, String email) {
		super();
		this.mobileNo = mobileNo;
		this.name = name;
		this.password = password;
		this.email = email;
	}



	public Admin(String mobileNo) {
		super();
		this.mobileNo = mobileNo;
	}



	public String getMobileNo() {
		return mobileNo;
	}



	public String getName() {
		return name;
	}



	public String getPassword() {
		return password;
	}



	public String getEmail() {
		return email;
	}



	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}



	public void setName(String name) {
		this.name = name;
	}



	public void setPassword(String password) {
		this.password = password;
	}



	public void setEmail(String email) {
		this.email = email;
	}



	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Admin [mobileNo=");
		builder.append(mobileNo);
		builder.append(", name=");
		builder.append(name);
		builder.append(", password=");
		builder.append(password);
		builder.append(", email=");
		builder.append(email);
		builder.append("]");
		return builder.toString();
	}



	
}
