package com.cg.capstore.repo;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.capstore.bean.Merchant;
import com.cg.capstore.exception.DuplicateIdException;
import com.cg.capstore.exception.InvalidIdException;
import com.cg.capstore.exception.merchantDoesNotExistsException;


@Transactional
@Repository
public class MerchantRepoImpl implements IMerchantRepo
{
	@PersistenceContext
	private EntityManager merchantEntityManager;
	
	//getter
	public EntityManager getEntityManager()
	{
		return merchantEntityManager;
	}
	
	@Override
	public Merchant addMerchant(Merchant merchant) throws DuplicateIdException
	{
		String id=merchant.getMerchantMobileNo();
		
		if(merchantEntityManager.find(Merchant.class,id)!=null)
		{
			throw new DuplicateIdException();
		}
		else
		{
			merchantEntityManager.persist(merchant);
			merchantEntityManager.flush();
			return merchant;
		}
	}

	@Override
	public Merchant findMerchant(String merchantId) throws InvalidIdException
	{
		
		Merchant merchant=merchantEntityManager.find(Merchant.class, merchantId);
		if(merchant==null)
		{
			throw new InvalidIdException();
		}
		else
		{
			return merchant;
		}
	}

	@Override
	public Merchant updateMerchant(Merchant merchant) throws merchantDoesNotExistsException
	{
		if(merchantEntityManager.find(Merchant.class, merchant.getMerchantMobileNo())==null)
		{
			throw new merchantDoesNotExistsException();
		}
		else
		{
			merchantEntityManager.merge(merchant);
			merchantEntityManager.flush();
			return merchant;
		}
	}

	@Override
	public List<Merchant> getMerchantList() throws merchantDoesNotExistsException {
		
		TypedQuery<Merchant> query=merchantEntityManager.createQuery("select merchant from Merchant merchant", Merchant.class);
		List<Merchant> list=query.getResultList();
		return list;
	}

	@Override
	public Merchant removeMerchant(String merchantId) throws InvalidIdException {
		Merchant merchant=merchantEntityManager.find(Merchant.class,merchantId);
		if(merchant==null)
		{
			throw new InvalidIdException();
		}
		else
		{
			merchantEntityManager.remove(merchantId);
			return merchant;
		}
	}


}
