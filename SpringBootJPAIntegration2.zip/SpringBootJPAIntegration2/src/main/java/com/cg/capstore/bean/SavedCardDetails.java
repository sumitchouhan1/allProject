package com.cg.capstore.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name= "SavedCard")
public class SavedCardDetails 
{
	@Id
	@Column(name="id")
	private String id;
	@Column(name="cardHolderName",length=50)
	private String cardHolderName;
	@Column(name="cardNo",length=16)
	private String cardNumber;
	@Column(name="expiryMonth",length=2)
	private  int expiryMonth;
	@Column(name="expiryYear",length=4)
	private int expiryYear;
	@ManyToOne
	@JoinColumn(name="customerId")
	private Customer customerCard;
	
	public SavedCardDetails() 
	{
		super();
	}

	public SavedCardDetails(String id, String cardHolderName, String cardNumber, int expiryMonth, int expiryYear,
			Customer customerCard) {
		super();
		this.id = id;
		this.cardHolderName = cardHolderName;
		this.cardNumber = cardNumber;
		this.expiryMonth = expiryMonth;
		this.expiryYear = expiryYear;
		this.customerCard = customerCard;
	}

	public SavedCardDetails(String id) {
		super();
		this.id = id;
	}

	public String getId() {
		return id;
	}

	public String getCardHolderName() {
		return cardHolderName;
	}

	public String getCardNumber() {
		return cardNumber;
	}

	public int getExpiryMonth() {
		return expiryMonth;
	}

	public int getExpiryYear() {
		return expiryYear;
	}

	public Customer getCustomerCard() {
		return customerCard;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setCardHolderName(String cardHolderName) {
		this.cardHolderName = cardHolderName;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public void setExpiryMonth(int expiryMonth) {
		this.expiryMonth = expiryMonth;
	}

	public void setExpiryYear(int expiryYear) {
		this.expiryYear = expiryYear;
	}

	public void setCustomerCard(Customer customerCard) {
		this.customerCard = customerCard;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("SavedCardDetails [id=");
		builder.append(id);
		builder.append(", cardHolderName=");
		builder.append(cardHolderName);
		builder.append(", cardNumber=");
		builder.append(cardNumber);
		builder.append(", expiryMonth=");
		builder.append(expiryMonth);
		builder.append(", expiryYear=");
		builder.append(expiryYear);
		builder.append(", customerCard=");
		builder.append(customerCard);
		builder.append("]");
		return builder.toString();
	}
	
}
