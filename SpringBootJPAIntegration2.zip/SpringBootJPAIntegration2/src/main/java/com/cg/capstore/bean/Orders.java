package com.cg.capstore.bean;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="Orders")
public class Orders
{
	@Id
	@Column(name="orderId",length=10)
	private String orderId;
	@Column(name="purchaseDate",length=50)
	@Temporal(TemporalType.DATE)
	private Date purchaseDate;
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="deliveryAddress")
	private Address deliveryAddress;
	@Column(name="deliverDate",length=50)
	@Temporal(TemporalType.DATE)
	private Date deliveryDate;
	@OneToOne(cascade=CascadeType.ALL)
	private  Invoice  invoice;	
	@Column(name="status",length=20)
	private String orderStatus;
        @Column(name="paymentOptions",length=20)
	private String paymentOptions;
	@Column(name="subTotal",length=10)
	private Double subTotal;
	@Column(name="paymentAccNo",length=16)
	private long paymentAccNo;
	
	@ManyToMany
	@JoinTable(name="ordersProduct",
	joinColumns=@JoinColumn(name="orderId"),
	inverseJoinColumns=@JoinColumn(name="prodId"))
	private List<Product> ordersProduct  = new ArrayList<>();
	
	@ManyToMany(cascade=CascadeType.ALL,mappedBy="cartOrder")
//	@JoinTable(name="cart_order",
//			joinColumns=@JoinColumn(name="order_id"),
//			inverseJoinColumns=@JoinColumn(name="cart_id"))
	private List<Cart> cart;
	
	public Orders() 
	{
		super();
	}

	public Orders(String orderId, Date purchaseDate, Address deliveryAddress, Date deliveryDate, Invoice invoice,
			String orderStatus, String paymentOptions, Double subTotal, long paymentAccNo, List<Product> ordersProduct,
			List<Cart> cart) {
		super();
		this.orderId = orderId;
		this.purchaseDate = purchaseDate;
		this.deliveryAddress = deliveryAddress;
		this.deliveryDate = deliveryDate;
		this.invoice = invoice;
		this.orderStatus = orderStatus;
		this.paymentOptions = paymentOptions;
		this.subTotal = subTotal;
		this.paymentAccNo = paymentAccNo;
		this.ordersProduct = ordersProduct;
		this.cart = cart;
	}

	public Orders(String orderId) {
		super();
		this.orderId = orderId;
	}

	public String getOrderId() {
		return orderId;
	}

	public Date getPurchaseDate() {
		return purchaseDate;
	}

	public Address getDeliveryAddress() {
		return deliveryAddress;
	}

	public Date getDeliveryDate() {
		return deliveryDate;
	}

	public Invoice getInvoice() {
		return invoice;
	}

	public String getOrderStatus() {
		return orderStatus;
	}

	public String getPaymentOptions() {
		return paymentOptions;
	}

	public Double getSubTotal() {
		return subTotal;
	}

	public long getPaymentAccNo() {
		return paymentAccNo;
	}

	public List<Product> getOrdersProduct() {
		return ordersProduct;
	}

	public List<Cart> getCart() {
		return cart;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public void setPurchaseDate(Date purchaseDate) {
		this.purchaseDate = purchaseDate;
	}

	public void setDeliveryAddress(Address deliveryAddress) {
		this.deliveryAddress = deliveryAddress;
	}

	public void setDeliveryDate(Date deliveryDate) {
		this.deliveryDate = deliveryDate;
	}

	public void setInvoice(Invoice invoice) {
		this.invoice = invoice;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}

	public void setPaymentOptions(String paymentOptions) {
		this.paymentOptions = paymentOptions;
	}

	public void setSubTotal(Double subTotal) {
		this.subTotal = subTotal;
	}

	public void setPaymentAccNo(long paymentAccNo) {
		this.paymentAccNo = paymentAccNo;
	}

	public void setOrdersProduct(List<Product> ordersProduct) {
		this.ordersProduct = ordersProduct;
	}

	public void setCart(List<Cart> cart) {
		this.cart = cart;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Orders [orderId=");
		builder.append(orderId);
		builder.append(", purchaseDate=");
		builder.append(purchaseDate);
		builder.append(", deliveryAddress=");
		builder.append(deliveryAddress);
		builder.append(", deliveryDate=");
		builder.append(deliveryDate);
		builder.append(", invoice=");
		builder.append(invoice);
		builder.append(", orderStatus=");
		builder.append(orderStatus);
		builder.append(", paymentOptions=");
		builder.append(paymentOptions);
		builder.append(", subTotal=");
		builder.append(subTotal);
		builder.append(", paymentAccNo=");
		builder.append(paymentAccNo);
		builder.append(", ordersProduct=");
		builder.append(ordersProduct);
		builder.append(", cart=");
		builder.append(cart);
		builder.append("]");
		return builder.toString();
	}

	
}