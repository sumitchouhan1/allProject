package com.cg.capstore.bean;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="address")
public class Address 
{
	@Id
	private String addressId;
	@Column(name="houseNo",length=10)
	private String houseNo;
	@Column(name="area",length=20)
	private String area;
	@Column(name="city",length=20)
	private String city;
	@Column(name="pincode",length=6)
	private String pincode;
	@Column(name="states",length=30)
	private String states;
	@Column(name="landmark",length=50)
	private String landmark;
	@Column(name="name",length=50)
	private String name;
	@Column(name="alternateMobile",length=10)
	private String alternateMobile_no;
	@Column(name="addressType",length=10)
	private String addressType;
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="customer_id")
	private Customer customerAddress;
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="merchantId")
	private Merchant merchantAddress;
	
	public Address()
	{
		super();
	}

	

	public Address(String addressId, String houseNo, String area, String city, String pincode, String states,
			String landmark, String name, String alternateMobile_no, String addressType, Customer customerAddress,
			Merchant merchantAddress) {
		super();
		this.addressId = addressId;
		this.houseNo = houseNo;
		this.area = area;
		this.city = city;
		this.pincode = pincode;
		this.states = states;
		this.landmark = landmark;
		this.name = name;
		this.alternateMobile_no = alternateMobile_no;
		this.addressType = addressType;
		this.customerAddress = customerAddress;
		this.merchantAddress = merchantAddress;
	}

	

	public Address(String addressId) {
		super();
		this.addressId = addressId;
	}



	public String getAddressId() {
		return addressId;
	}



	public String getHouseNo() {
		return houseNo;
	}



	public String getArea() {
		return area;
	}



	public String getCity() {
		return city;
	}



	public String getPincode() {
		return pincode;
	}



	public String getStates() {
		return states;
	}



	public String getLandmark() {
		return landmark;
	}



	public String getName() {
		return name;
	}



	public String getAlternateMobile_no() {
		return alternateMobile_no;
	}



	public String getAddressType() {
		return addressType;
	}



	public Customer getCustomerAddress() {
		return customerAddress;
	}



	public Merchant getMerchantAddress() {
		return merchantAddress;
	}



	public void setAddressId(String addressId) {
		this.addressId = addressId;
	}



	public void setHouseNo(String houseNo) {
		this.houseNo = houseNo;
	}



	public void setArea(String area) {
		this.area = area;
	}



	public void setCity(String city) {
		this.city = city;
	}



	public void setPincode(String pincode) {
		this.pincode = pincode;
	}



	public void setStates(String states) {
		this.states = states;
	}



	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}



	public void setName(String name) {
		this.name = name;
	}



	public void setAlternateMobile_no(String alternateMobile_no) {
		this.alternateMobile_no = alternateMobile_no;
	}



	public void setAddressType(String addressType) {
		this.addressType = addressType;
	}



	public void setCustomerAddress(Customer customerAddress) {
		this.customerAddress = customerAddress;
	}



	public void setMerchantAddress(Merchant merchantAddress) {
		this.merchantAddress = merchantAddress;
	}



	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Address [addressId=");
		builder.append(addressId);
		builder.append(", houseNo=");
		builder.append(houseNo);
		builder.append(", area=");
		builder.append(area);
		builder.append(", city=");
		builder.append(city);
		builder.append(", pincode=");
		builder.append(pincode);
		builder.append(", states=");
		builder.append(states);
		builder.append(", landmark=");
		builder.append(landmark);
		builder.append(", name=");
		builder.append(name);
		builder.append(", alternateMobile_no=");
		builder.append(alternateMobile_no);
		builder.append(", addressType=");
		builder.append(addressType);
		builder.append(", customerAddress=");
		builder.append(customerAddress);
		builder.append(", merchantAddress=");
		builder.append(merchantAddress);
		builder.append("]");
		return builder.toString();
	}


	
	
}
