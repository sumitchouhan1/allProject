package com.cg.capstore.bean;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="Merchant")
public class Merchant 
{
	@Id
	@Column(name="merchantMobileNo")
	private String merchantMobileNo;
	@Column(name="merchantName",length=50)
	private String merchantName;
	@Column(name="email",length=70)
	private String email;
	@Column(name="password",length=20)
	private String password;
	@Column(name="merchantType",length=50)
	private String merchantType;
	@OneToMany(cascade=CascadeType.ALL,mappedBy="merchantAddress")
	private List<Address> addresses=new ArrayList<>();
	
	@ManyToMany(mappedBy="merchantFeedback")
//	@JoinTable(name="merchant_feedback"
//			,joinColumns=@JoinColumn(name="feedback_id")
//			,inverseJoinColumns= 
//			{
//					@JoinColumn(name="merchant_id",referencedColumnName="merchant_mobile_no")
//					,@JoinColumn(name="customer_id",referencedColumnName="customer_mobile_no")
//			}
//			)
	private List<Feedback> feedback=new ArrayList<>();
	
	@ManyToMany(mappedBy="merchantResponse")
//	@JoinTable(name="merchant_response"
//			,joinColumns=@JoinColumn(name="response_id")
//			,inverseJoinColumns= 
//			{
//					@JoinColumn(name="merchant_id",referencedColumnName="merchant_mobile_no")
//					,@JoinColumn(name="customer_id",referencedColumnName="customer_mobile_no")
//			}
//			)
	private List<Response> response=new ArrayList<>();
	
	@ManyToMany(mappedBy="merchantProduct")
//	@JoinTable(name="merchant_product"
//					,joinColumns=@JoinColumn(name="merchant_id")
//					,inverseJoinColumns= {@JoinColumn(name="prod_id")}
//			  )
	private List<Product> products = new ArrayList<>();
 	
	
	
	public Merchant() 
	{
		super();
	}



	public Merchant(String merchantMobileNo, String merchantName, String email, String password, String merchantType,
			List<Address> addresses, List<Feedback> feedback, List<Response> response, List<Product> products) {
		super();
		this.merchantMobileNo = merchantMobileNo;
		this.merchantName = merchantName;
		this.email = email;
		this.password = password;
		this.merchantType = merchantType;
		this.addresses = addresses;
		this.feedback = feedback;
		this.response = response;
		this.products = products;
	}



	public Merchant(String merchantMobileNo) {
		super();
		this.merchantMobileNo = merchantMobileNo;
	}



	public String getMerchantMobileNo() {
		return merchantMobileNo;
	}



	public String getMerchantName() {
		return merchantName;
	}



	public String getEmail() {
		return email;
	}



	public String getPassword() {
		return password;
	}



	public String getMerchantType() {
		return merchantType;
	}



	public List<Address> getAddresses() {
		return addresses;
	}



	public List<Feedback> getFeedback() {
		return feedback;
	}



	public List<Response> getResponse() {
		return response;
	}



	public List<Product> getProducts() {
		return products;
	}



	public void setMerchantMobileNo(String merchantMobileNo) {
		this.merchantMobileNo = merchantMobileNo;
	}



	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}



	public void setEmail(String email) {
		this.email = email;
	}



	public void setPassword(String password) {
		this.password = password;
	}



	public void setMerchantType(String merchantType) {
		this.merchantType = merchantType;
	}



	public void setAddresses(List<Address> addresses) {
		this.addresses = addresses;
	}



	public void setFeedback(List<Feedback> feedback) {
		this.feedback = feedback;
	}



	public void setResponse(List<Response> response) {
		this.response = response;
	}



	public void setProducts(List<Product> products) {
		this.products = products;
	}



	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Merchant [merchantMobileNo=");
		builder.append(merchantMobileNo);
		builder.append(", merchantName=");
		builder.append(merchantName);
		builder.append(", email=");
		builder.append(email);
		builder.append(", password=");
		builder.append(password);
		builder.append(", merchantType=");
		builder.append(merchantType);
		builder.append(", addresses=");
		builder.append(addresses);
		builder.append(", feedback=");
		builder.append(feedback);
		builder.append(", response=");
		builder.append(response);
		builder.append(", products=");
		builder.append(products);
		builder.append("]");
		return builder.toString();
	}
	
}
