package com.cg.capstore.service;

import java.util.List;


import org.springframework.stereotype.Service;

import com.cg.capstore.bean.Merchant;
import com.cg.capstore.exception.DuplicateIdException;
import com.cg.capstore.exception.InvalidIdException;
import com.cg.capstore.exception.merchantDoesNotExistsException;

@Service
public interface IMerchantService {
	Merchant addMerchant(Merchant merchant) throws DuplicateIdException; 
	Merchant findMerchant(String id) throws InvalidIdException;
	Merchant updateMerchant(Merchant merchant) throws merchantDoesNotExistsException;
	List<Merchant> getMerchantList() throws merchantDoesNotExistsException;
	Merchant removeMerchant(String merchantId) throws InvalidIdException;

}
