package com.cg.capstore.bean;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="Feedback")
public class Feedback
{
	@Id
	@Column(name="feedbackId",length=10)
	private String feedbackId;
	@Column(name="description")
	private String description;
	@Column(name="rating")
	private double rating;
	
	@ManyToMany
	@JoinTable(name="merchantFeedback"
			,joinColumns=@JoinColumn(name="feedbackId")
			,inverseJoinColumns= {
					@JoinColumn(name="merchantId",referencedColumnName="merchantMobileNo")
					}
			)
	private List<Merchant> merchantFeedback=new ArrayList<>(); 
	@ManyToMany
	@JoinTable(name="merchantFeedback"
			,joinColumns=@JoinColumn(name="feedbackId")
			,inverseJoinColumns= 
			{
					@JoinColumn(name="customerId",referencedColumnName="customerMobileNo")
			})
	private List<Customer> customerFeedback=new ArrayList<>();
	@ManyToMany
	@JoinTable(name="productFeedback"
			,joinColumns=@JoinColumn(name="prodId")
			,inverseJoinColumns= @JoinColumn(name="feedbackId")
			)
	private List<Feedback> prodFeedback=new ArrayList<>(); 

	
	
	
	
	
	
	public Feedback() 
	{
		super();
	}







	public Feedback(String feedbackId, String description, double rating, List<Merchant> merchantFeedback,
			List<Customer> customerFeedback, List<Feedback> prodFeedback) {
		super();
		this.feedbackId = feedbackId;
		this.description = description;
		this.rating = rating;
		this.merchantFeedback = merchantFeedback;
		this.customerFeedback = customerFeedback;
		this.prodFeedback = prodFeedback;
	}







	public Feedback(String feedbackId) {
		super();
		this.feedbackId = feedbackId;
	}







	public String getFeedbackId() {
		return feedbackId;
	}







	public String getDescription() {
		return description;
	}







	public double getRating() {
		return rating;
	}







	public List<Merchant> getMerchantFeedback() {
		return merchantFeedback;
	}







	public List<Customer> getCustomerFeedback() {
		return customerFeedback;
	}







	public List<Feedback> getProdFeedback() {
		return prodFeedback;
	}







	public void setFeedbackId(String feedbackId) {
		this.feedbackId = feedbackId;
	}







	public void setDescription(String description) {
		this.description = description;
	}







	public void setRating(double rating) {
		this.rating = rating;
	}







	public void setMerchantFeedback(List<Merchant> merchantFeedback) {
		this.merchantFeedback = merchantFeedback;
	}







	public void setCustomerFeedback(List<Customer> customerFeedback) {
		this.customerFeedback = customerFeedback;
	}







	public void setProdFeedback(List<Feedback> prodFeedback) {
		this.prodFeedback = prodFeedback;
	}







	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Feedback [feedbackId=");
		builder.append(feedbackId);
		builder.append(", description=");
		builder.append(description);
		builder.append(", rating=");
		builder.append(rating);
		builder.append(", merchantFeedback=");
		builder.append(merchantFeedback);
		builder.append(", customerFeedback=");
		builder.append(customerFeedback);
		builder.append(", prodFeedback=");
		builder.append(prodFeedback);
		builder.append("]");
		return builder.toString();
	}

	
}
