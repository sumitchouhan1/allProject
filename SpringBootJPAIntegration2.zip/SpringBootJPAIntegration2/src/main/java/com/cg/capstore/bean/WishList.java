package com.cg.capstore.bean;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="WishList")
public class WishList 
{
	@Id
	@Column(name="wishListId")
	private String wishListId;
	@ManyToMany
	@JoinTable(name="wishListProduct",
				joinColumns=@JoinColumn(name="prodId"),
				inverseJoinColumns=@JoinColumn(name="wishListId"))
	private List<Product> wishListProduct=new ArrayList<>();
	
	public WishList()
	{
		super();
	}

	public WishList(String wishListId, List<Product> wishListProduct) {
		super();
		this.wishListId = wishListId;
		this.wishListProduct = wishListProduct;
	}

	public WishList(String wishListId) {
		super();
		this.wishListId = wishListId;
	}

	public String getWishListId() {
		return wishListId;
	}

	public List<Product> getWishListProduct() {
		return wishListProduct;
	}

	public void setWishListId(String wishListId) {
		this.wishListId = wishListId;
	}

	public void setWishListProduct(List<Product> wishListProduct) {
		this.wishListProduct = wishListProduct;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("WishList [wishListId=");
		builder.append(wishListId);
		builder.append(", wishListProduct=");
		builder.append(wishListProduct);
		builder.append("]");
		return builder.toString();
	}
	
}
