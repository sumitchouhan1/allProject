package com.cg.pag2.bean;

public class Person {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		System.out.println("Personal Details:");
		System.out.println();
		System.out.println("________");
		System.out.println("First Name: Himanshu");
		System.out.println("Last Name: Mishra");
		System.out.println("Gender:M");
		System.out.println("Age:20");
		System.out.println("Weight:75");
		
		
		

	}

}
