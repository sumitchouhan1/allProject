package com.cg.springmvc.service;

import java.util.List;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.springmvc.bean.Wishlist;
import com.cg.springmvc.repo.IWishListRepo;

@Service
public class WishListServiceImpl implements IWishListService
{
	
	@Autowired
	IWishListRepo wishListRepo;

	@Override
	public Wishlist addToWishlist(Wishlist wishList)
	{
		return wishListRepo.addToWishlist(wishList);
	}

	@Override
	public List<Wishlist> getWishListList() {
		
		return wishListRepo.getWishListList();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	}
