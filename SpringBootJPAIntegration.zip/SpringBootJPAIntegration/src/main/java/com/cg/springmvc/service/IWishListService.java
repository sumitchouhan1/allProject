package com.cg.springmvc.service;

import java.util.List;



import org.springframework.stereotype.Service;

import com.cg.springmvc.bean.Wishlist;

@Service
public interface IWishListService
{
	Wishlist addToWishlist(Wishlist wishList) ; 
	List<Wishlist> getWishListList() ;

}
