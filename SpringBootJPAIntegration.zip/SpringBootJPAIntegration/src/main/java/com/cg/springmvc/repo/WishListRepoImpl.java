package com.cg.springmvc.repo;


import java.util.List;



import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.springmvc.bean.Wishlist;



@Transactional
@Repository
public class WishListRepoImpl implements IWishListRepo
{
	@PersistenceContext
	private EntityManager entityManager;
	
	//getter
	public EntityManager getEntityManager()
	{
		return entityManager;
	}

	@Override
	public Wishlist addToWishlist(Wishlist wishList)
	{
		
		
			entityManager.persist(wishList);
			entityManager.flush();
			return wishList;
			
	
	}

	@Override
	public List<Wishlist> getWishListList()
	{
		Query query=entityManager.createNativeQuery("select * from wish_list");
		
		List<Wishlist> list=query.getResultList();
		return list; 
	}
	

}
