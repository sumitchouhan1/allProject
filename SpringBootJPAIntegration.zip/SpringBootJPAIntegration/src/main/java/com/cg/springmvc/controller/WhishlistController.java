package com.cg.springmvc.controller;

import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.springmvc.bean.Wishlist;
import com.cg.springmvc.service.IWishListService;

@RestController
public class WhishlistController
{
	@Autowired
	IWishListService wishListServices;
	EntityManager entityManager;
	
	
	
	@RequestMapping("/hello")
	public String sayHi()
	{
		return "Hey...";
	}
	
	
	@RequestMapping(value="/addToWhishlist", method=RequestMethod.POST,produces="application/json", consumes="application/json")
	public Wishlist addToWishList(@RequestBody Wishlist wishList)
	{
		wishListServices.addToWishlist(wishList);
		return wishList;
	}
	
	
	@RequestMapping(value="/viewList", method=RequestMethod.POST,produces="application/json")
	public List<Wishlist> viewWishList()
	{
		System.out.println("*****************************************************");
		List<Wishlist> list= wishListServices.getWishListList();
		System.out.println("************************************************"+list.size());
		return list;
	}
	
	
	
	
	
	
	
	
}
