package com.cg.springmvc.repo;

import java.util.List;



import org.springframework.stereotype.Repository;

import com.cg.springmvc.bean.Wishlist;


@Repository
public interface IWishListRepo
{
	Wishlist addToWishlist(Wishlist wishList) ; 
	List<Wishlist> getWishListList() ;
}
